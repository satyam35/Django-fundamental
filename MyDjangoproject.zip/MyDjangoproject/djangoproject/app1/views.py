from django.shortcuts import render

def index(request):
    return render(request,'index.html')
def expression(request):
    a=int(request.POST['value1'])
    b=int(request.POST['value2'])
    c=a*2+b
    return render(request,'expression.html',{'data':c})